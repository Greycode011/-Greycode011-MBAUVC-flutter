// Use this sample to create your own voice commands
intent('hello world', p => {
    p.play('(hello|hi there)');
});

intent('How are you', p => {
    p.play('(good thank you|great)');
});

let weatherRequests = [
    "(How is|What is) the (weather|temperature) (today|)",
    "today's forecast"
];

let weatherResponses = [
    "(It is|Feels|) (great|awesome)!",
    "Rainy, windy, and cold. (A complete mess!|)"
];

intent(weatherRequests,
    reply(weatherResponses));

intent('Do you know anything about $(TOPIC physics|mathematics|chemistry)', p => {
    p.play('Yes. I do know ' + p.TOPIC.value + '. (Ask me anything about it!|)')
});

// Predefined slot
intent('How much is $(NUMBER) plus $(NUMBER)', p => {
    let result = p.NUMBERs[0].number + p.NUMBERs[1].number
    p.play(`It is ${result}`);
});

intent('I want $(NUMBER) (cup_) of tea', p => {
    p.play('Here you go');
});

intent('Talk to me', p => {
    p.play('Sure, what do you want to talk about?');
});

intent('Open the menu', p => {
    p.play({command: 'navigate', screen: 'menu'});
    p.play('Opening the menu');
});


intent('Go back', p => {
    p.play({command: 'navigate', screen: 'back'});
    p.play('Going back');
});

intent('Set a 1-minute timer', p => {
    p.play({command: 'setTimer'});
    p.play('Sure, 1 minute, starting now',  opts({deactivate:true}));
    setTimeout(() => {
        p.play({command: 'notifyUser', text: 'You are half way there'}, opts({force:true}));
    }, 30000)
    setTimeout(() => {
        p.play({command: 'stopTimer'}, opts({force:true}));
        p.play('Time is up', opts({activate:true, deactivate:true}))
    }, 60000)
});


let storyTellerVoice = voice(en, 'male', 0, 0, 1);
let motherVoice = voice(en, 'female', 0, 1, 1);
let redHatVoice = voice(en, 'female', 0, 10, 1.2);

intent("Alan, tell me a fairy tale", p => {
    p.play(storyTellerVoice, "Once upon a time there was a sweet little girl who always wore a cap made of red velvet.");
    p.play(storyTellerVoice, "One day her mother said to her");
    p.play(motherVoice, "Come Little Red Cap. Here is a piece of cake and a bottle of wine. Take them to your grandmother.");
    p.play(storyTellerVoice, "Little Red Cap said");
    p.play(redHatVoice, "I'll do everything just right.");
});


intent("What is my location?", async p => {
    let addr = await getLocation(p);
    if (addr) {
        p.play(`You are at ${addr}`);
    }
    else {
        p.play("I can't understand where you are");
    }
});

function getLocation(p) {
    let address = "test address"; //Here will be some api call
    if (address) {
        return Promise.resolve(address);
    }
    else {
        return Promise.resolve();
    }
}


let userRating = context(() => {
    intent(`$(NUMBER)`, async p => p.resolve(p.NUMBER.value))
});

intent('I want to take survey', async p => {
    p.play('Please rate the project on the scale of 1 to 5');
    let rating = await p.then(userRating);
    p.play(`Thank you for sharing your opinion. Your rating is: ${rating}`);
});



let countContext = context(() => {
    onEnter(p => {
        p.state.result = 0;
    });

    intent('Yes', p => {
        p.state.result += 1;
        p.play(p.state.result.toString());
    });
});

intent("Count how many times I've said yes", p =>{
    p.play("Sure, Let's go");
    p.then(countContext);
});


function diffFrom(ts, units) {
    let last = DateTime.fromMillis(ts);
    let now  = DateTime.local();
    console.log(`now.diff(last): ${now.diff(last)}`);
    console.log(`units: ${units}, now.diff(last).as(units): ${now.diff(last).as(units)}`);
    return now.diff(last).as(units);
}

onUserEvent((p, e) => {
    console.info('event', JSON.stringify(e));
    if (e.event == 'firstActivate') {
        if (diffFrom(e.userInfo.lastInteractionTs, 'days') > 1) {
            p.play('(Hi|Hi there|Hello), I am Alan, your in-app assistant. Ask any question or tell me what you would like to do');
        }
    }
});